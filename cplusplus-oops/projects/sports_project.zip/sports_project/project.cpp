#include <iostream>
#include <string>
#include <limits>      
#include <cctype>      
#include <vector>     
#include <algorithm>  
#include <iomanip>    
#include <fstream>   
using namespace std;

//Base class of the program
class Player
{
protected:
public:
    //Components of Player common for all 3 Player.
    string First_name;
    string Last_name;
    int Age;
    string Team;
    string Country;
    int Win;
    int Lost;
    int No_of_matches;

    Player() //Default Constructor
    {
        First_name = "";
        Last_name = "";
        Age = 0;
        Team = "";
        Country = "";
        Win = 0;
        Lost = 0;
        No_of_matches = 0;
    }

    //Parameterized Constructor
    Player(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches)
    {
        First_name = first_name;
        Last_name = last_name;
        Age = age;
        Team = team;
        Country = country;
        Win = win;
        Lost = lost;
        No_of_matches = no_of_matches;
    }

    ~Player() {} //Destructor

    virtual void displaymain()
    {
        cout << "\t\t\t\t**********************************" << endl;
        cout << "\t\t\t\tWELCOME TO Player ANALYZER PROGRAM" << endl;
        cout << "\t\t\t\t**********************************" << endl;

        cout << "\t\t\t\tPlease Choose the Player by pressing the number next to it : " << endl
             << endl;
        cout << "\t\t\t\t1) Football" << endl;
        cout << "\t\t\t\t2) Cricket" << endl;
        cout << "\t\t\t\t0) To exit the program " << endl
             << endl;
        cout << "\t\t\t\tEnter your choice: ";
    }
};

//Base class for football ---> Inherited from class "Player"
class Football : public Player
{
protected:
public:
    string Position;
    int Pass_Accuracy;
    int Red_card;
    int Draw;

    Football() //Default Constructor for Football class
    {
        Position = "";
        Pass_Accuracy = 0;
        Red_card = 0;
        Draw = 0;
    }

    //Parameterized Constructor for Football class
    Football(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, string position, int pass_accuracy, int red_card, int draw) : Player(first_name, last_name, age, team, country, win, lost, no_of_matches)
    {
        Position = position;
        Pass_Accuracy = pass_accuracy;
        Red_card = red_card;
        Draw = draw;
    }

    ~Football() {} //Deconstructor for Football class

    void displaymain() override
    {
        cout << "\t\t\t\t**********************************" << endl;
        cout << "\t\t\t\tWELCOME TO Player ANALYZER PROGRAM" << endl;
        cout << "\t\t\t\t**********************************" << endl
             << endl
             << endl;
        cout << "\t\t\t\t>>>>>> Welcome to Football <<<<<<" << endl
             << endl;
        cout << "\t\t\t\t1. View Teams " << endl;
        cout << "\t\t\t\t2. View Players " << endl;
        cout << "\t\t\t\t3. Stats " << endl;
        cout << "\t\t\t\t4. Standings " << endl;
        cout << "\t\t\t\t5. Return to Main Menu" << endl;
        cout << "\t\t\t\t0. EXIT" << endl
             << endl;
        cout << "\t\t\t\tEnter your choice: ";
    }

    void Team_display_f() //For diplaying the teams of football
    {
        fstream team_f("team_f.txt");
        string f;
        if (!team_f)
            cout << "Error" << endl;
        else
        {
            while (!team_f.eof())
            {
                getline(team_f, f);
                cout << f << endl;
            }
        }
    }

    void Standings_display_f() //For displaying the standings of football
    {
        fstream standings_f("standings_f.txt");
        string f;
        if (!standings_f)
            cout << "Error" << endl;
        else
        {
            while (!standings_f.eof())
            {
                getline(standings_f, f);
                cout << f << endl;
            }
        }
    }
};
//Attack class (Inherited from Football class --> Will contain all the components of Football as well as its parent class Player)
class Attack : public Football
{
protected:
public:
    int Goals;
    float Shot_accuracy;
    int Assist;

    Attack() // Default Constructor for Attack class
    {
        Goals = 0;
        Shot_accuracy = 0;
        Assist = 0;
    }

    // Parameterized Constructor for Attack class
    Attack(string first_name, string last_name, int age, string team, string country, int win, int lost, string position, int no_of_matches, int assist, int pass_accuracy, int red_card, int draw, int goals, float shot_accurracy) : Football(first_name, last_name, age, team, country, win, lost, no_of_matches, position, pass_accuracy, red_card, draw)
    {
        Assist = assist;
        Goals = goals;
        Shot_accuracy = shot_accurracy;
    }

    ~Attack() {} // Destructor for Attack class

    void Display_stats_f_a( vector<Attack>& A)
    {
        fstream stats_f_a("attack.txt");
        int id[60];
        int _id = 1;
        for (int i = 0; i < 60; i++)
        {
            id[i] = _id;
            _id++;
        }

        stats_f_a.seekg(0);
        for (int i = 0; i < 58; i++)
        {
            stats_f_a >> A[i].First_name >> A[i].Last_name >> A[i].Position >> A[i].Age >> A[i].Team >> A[i].Country >> A[i].No_of_matches >> A[i].Goals >> A[i].Shot_accuracy >> A[i].Assist >> A[i].Pass_Accuracy >> A[i].Red_card;
        }
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM               COUNTRY      App  Goals S.Accu Ass P.Accu RCd" << endl
             << endl
             << endl;
        for (int i = 0; i < 58; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << A[i].First_name << setw(14) << A[i].Last_name << setw(5) << A[i].Position << setw(4) << A[i].Age << setw(19) << A[i].Team << setw(13) << A[i].Country << setw(5) << A[i].No_of_matches << setw(6) << A[i].Goals << setw(7) << A[i].Shot_accuracy << setw(4) << A[i].Assist << setw(7) << A[i].Pass_Accuracy << setw(3) << A[i].Red_card << endl;
            cout << "-----------------------------------------------------------------------------------------------------" << endl;
        }
    }

    void Search_player_f_a( vector<Attack>& A, string name)
    {
        fstream psearch_a("attack.txt");
        int id[60];
        int _id = 1;
        for (int i = 0; i < 60; i++)
        {
            id[i] = _id;
            _id++;
        }
        psearch_a.seekg(0);

        for (int i = 0; i < 58; i++)
        {
            psearch_a >> A[i].First_name >> A[i].Last_name >> A[i].Position >> A[i].Age >> A[i].Team >> A[i].Country >> A[i].No_of_matches >> A[i].Goals >> A[i].Shot_accuracy >> A[i].Assist >> A[i].Pass_Accuracy >> A[i].Red_card;
        }

        int check = 0;

        for (int i = 0; i < 58; i++)
        {
            if (name == A[i].First_name || name == A[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY      App  Goals S.Accu Ass P.Accu RCd" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 58; i++)
        {
            if (name == A[i].First_name || name == A[i].Last_name)
            {
                cout << left << setw(4) << id[i] << setw(10) << A[i].First_name << setw(14) << A[i].Last_name << setw(5) << A[i].Position << setw(4) << A[i].Age << setw(22) << A[i].Team << setw(13) << A[i].Country << setw(5) << A[i].No_of_matches << setw(6) << A[i].Goals << setw(7) << A[i].Shot_accuracy << setw(4) << A[i].Assist << setw(7) << A[i].Pass_Accuracy << setw(3) << A[i].Red_card << endl;
                cout << "---------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Player_display_f_a( vector<Attack>& A)
    {
        fstream player_f_a("attack.txt");

        int id[60];
        int _id = 1;
        for (int i = 0; i < 60; i++)
        {
            id[i] = _id;
            _id++;
        }
        player_f_a.seekg(0);

        for (int i = 0; i < 60; i++)
        {
            player_f_a >> A[i].First_name >> A[i].Last_name >> A[i].Position >> A[i].Age >> A[i].Team >> A[i].Country >> A[i].No_of_matches >> A[i].Goals >> A[i].Shot_accuracy >> A[i].Assist >> A[i].Pass_Accuracy >> A[i].Red_card;
        }
        cout << "FORWARD : " << endl
             << endl;
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM               COUNTRY" << endl
             << endl;
        for (int i = 0; i < 45; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << A[i].First_name << setw(14) << A[i].Last_name << setw(5) << A[i].Position << setw(4) << A[i].Age << setw(19) << A[i].Team << setw(13) << A[i].Country << endl;
            cout << "----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }
};
//Midfield class (Inherited from Football class --> Will contain all the components of Football as well as its parent class Player)
class MidField : public Football
{
protected:
public:
    int Goals;
    float Shot_accuracy;
    int Assist;

    MidField() //Default Constructor for Midfield class
    {
        Goals = 0;
        Shot_accuracy = 0;
    }

    //Parameterized Constructor for Midfield class
    MidField(string first_name, string last_name, int age, string team, string country, int win, int lost, string position, int no_of_matches, int assist, int pass_accuracy, int red_card, int draw, int goals, float shot_accurracy) : Football(first_name, last_name, age, team, country, win, lost, no_of_matches, position, pass_accuracy, red_card, draw)
    {
        Goals = goals;
        Shot_accuracy = shot_accurracy;
        Assist = assist;
    }

    ~MidField() {} //Destructor for Midfield class

    void Display_stats_f_m(vector<MidField>& Mf)
    {
        fstream stats_f_m("midfield.txt");
        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }

        stats_f_m.seekg(0);
        for (int i = 0; i < 111; i++)
        {
            stats_f_m >> Mf[i].First_name >> Mf[i].Last_name >> Mf[i].Position >> Mf[i].Age >> Mf[i].Team >> Mf[i].Country >> Mf[i].No_of_matches >> Mf[i].Goals >> Mf[i].Shot_accuracy >> Mf[i].Assist >> Mf[i].Pass_Accuracy >> Mf[i].Red_card;
        }
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY      App  Goals S.Accu Ass P.Accu RCd" << endl
             << endl
             << endl;
        for (int i = 0; i < 111; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << Mf[i].First_name << setw(14) << Mf[i].Last_name << setw(5) << Mf[i].Position << setw(4) << Mf[i].Age << setw(22) << Mf[i].Team << setw(13) << Mf[i].Country << setw(5) << Mf[i].No_of_matches << setw(6) << Mf[i].Goals << setw(7) << Mf[i].Shot_accuracy << setw(4) << Mf[i].Assist << setw(7) << Mf[i].Pass_Accuracy << setw(3) << Mf[i].Red_card << endl;
            cout << "--------------------------------------------------------------------------------------------------------" << endl;
        }
    }

    void Search_player_f_m(vector<MidField>& Mf, string name)
    {
        fstream psearch_m("midfield.txt");
        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }
        psearch_m.seekg(0);
        for (int i = 0; i < 111; i++)
        {
            psearch_m >> Mf[i].First_name >> Mf[i].Last_name >> Mf[i].Position >> Mf[i].Age >> Mf[i].Team >> Mf[i].Country >> Mf[i].No_of_matches >> Mf[i].Goals >> Mf[i].Shot_accuracy >> Mf[i].Assist >> Mf[i].Pass_Accuracy >> Mf[i].Red_card;
        }

        int check = 0;

        for (int i = 0; i < 111; i++)
        {
            if (name == Mf[i].First_name || name == Mf[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY      App  Goals S.Accu Ass P.Accu RCd" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 111; i++)
        {
            if (name == Mf[i].First_name || name == Mf[i].Last_name)
            {
                cout << left << setw(4) << id[i] << setw(10) << Mf[i].First_name << setw(14) << Mf[i].Last_name << setw(5) << Mf[i].Position << setw(4) << Mf[i].Age << setw(22) << Mf[i].Team << setw(13) << Mf[i].Country << setw(5) << Mf[i].No_of_matches << setw(6) << Mf[i].Goals << setw(7) << Mf[i].Shot_accuracy << setw(4) << Mf[i].Assist << setw(7) << Mf[i].Pass_Accuracy << setw(3) << Mf[i].Red_card << endl;
                cout << "--------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Player_display_f_m(vector<MidField>& Mf)
    {
        fstream player_f_m("midfield.txt");

        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }
        player_f_m.seekg(0);
        for (int i = 0; i < 111; i++)
        {
            player_f_m >> Mf[i].First_name >> Mf[i].Last_name >> Mf[i].Position >> Mf[i].Age >> Mf[i].Team >> Mf[i].Country >> Mf[i].No_of_matches >> Mf[i].Goals >> Mf[i].Shot_accuracy >> Mf[i].Assist >> Mf[i].Pass_Accuracy >> Mf[i].Red_card;
        }
        cout << "MID-FIELD : " << endl
             << endl;
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY" << endl
             << endl;
        for (int i = 0; i < 111; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << Mf[i].First_name << setw(14) << Mf[i].Last_name << setw(5) << Mf[i].Position << setw(4) << Mf[i].Age << setw(22) << Mf[i].Team << setw(13) << Mf[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }
};
//Defence class (Inherited from Football class --> Will contain all the components of Football as well as its parent class Player)
class Defence : public Football
{
protected:
public:
    int Goals;
    int Tackles_won;
    int Clearance;
    int Blocked_shots;
    int Assist;

    Defence() //Default constructor for Defence class
    {
        Goals = 0;
        Tackles_won = 0;
        Clearance = 0;
        Blocked_shots = 0;
        Assist = 0;
    }

    //Parameterized Constructor for Defence class
    Defence(string first_name, string last_name, int age, string team, string country, int win, int lost, string position, int no_of_matches, int assist, int pass_accuracy, int red_card, int draw, int goals, int tackles_won, int clearance, int blocked_shots) : Football(first_name, last_name, age, team, country, win, lost, no_of_matches, position, pass_accuracy, red_card, draw)
    {
        Goals = goals;
        Tackles_won = tackles_won;
        Clearance = clearance;
        Blocked_shots = blocked_shots;
        Assist = assist;
    }

    ~Defence() {} //Destructor for Defence class

    void Display_stats_f_d(vector<Defence>& D)
    {
        fstream stats_f_d("DEFENDERS.txt");
        if (!stats_f_d)
            cout << "Error opening this file!!" << endl;

        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }

        stats_f_d.seekg(0);
        for (int i = 0; i < 107; i++)
        {
            stats_f_d >> D[i].First_name >> D[i].Last_name >> D[i].Position >> D[i].Age >> D[i].Team >> D[i].Country >> D[i].No_of_matches >> D[i].Tackles_won >> D[i].Clearance >> D[i].Blocked_shots >> D[i].Red_card >> D[i].Goals >> D[i].Pass_Accuracy;
        }
        cout << "SNO F.NAME    L.NAME        POS  AGE TEAM                  COUNTRY      APP  TACKLE CLEARANCE BLK.SHOT RC Goals P.ACC" << endl
             << endl
             << endl;
        for (int i = 0; i < 107; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << D[i].First_name << setw(14) << D[i].Last_name << setw(5) << D[i].Position << setw(4) << D[i].Age << setw(22) << D[i].Team << setw(13) << D[i].Country << setw(5) << D[i].No_of_matches << setw(7) << D[i].Tackles_won << setw(10) << D[i].Clearance << setw(9) << D[i].Blocked_shots << setw(3) << D[i].Red_card << setw(6) << D[i].Goals << setw(7) << D[i].Pass_Accuracy << endl;
            cout << "---------------------------------------------------------------------------------------------------------------------" << endl;
        }
    }

    void Search_player_f_d(vector<Defence>& D, string name)
    {
        fstream psearch_d("DEFENDERS.txt");
        if (!psearch_d)
            cout << "Error opening this file!!" << endl;
        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }
        psearch_d.seekg(0);
        for (int i = 0; i < 107; i++)
        {
            psearch_d >> D[i].First_name >> D[i].Last_name >> D[i].Position >> D[i].Age >> D[i].Team >> D[i].Country >> D[i].No_of_matches >> D[i].Tackles_won >> D[i].Clearance >> D[i].Blocked_shots >> D[i].Red_card >> D[i].Goals >> D[i].Pass_Accuracy;
        }

        int check = 0;

        for (int i = 0; i < 107; i++)
        {
            if (name == D[i].First_name || name == D[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "F.NAME    L.NAME        POS  AGE TEAM                  COUNTRY      APP  TACKLE CLEARANCE BLK.SHOT RC Goals P.ACC" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 107; i++)
        {
            if (name == D[i].First_name || name == D[i].Last_name)
            {
                cout << left << setw(10) << D[i].First_name << setw(14) << D[i].Last_name << setw(5) << D[i].Position << setw(4) << D[i].Age << setw(22) << D[i].Team << setw(13) << D[i].Country << setw(5) << D[i].No_of_matches << setw(7) << D[i].Tackles_won << setw(10) << D[i].Clearance << setw(9) << D[i].Blocked_shots << setw(3) << D[i].Red_card << setw(6) << D[i].Goals << setw(7) << D[i].Pass_Accuracy << endl;
                cout << "------------------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Player_display_f_d(vector<Defence>& D)
    {
        fstream player_f_d("DEFENDERS.txt");

        int id[120];
        int _id = 1;
        for (int i = 0; i < 120; i++)
        {
            id[i] = _id;
            _id++;
        }
        player_f_d.seekg(0);
        for (int i = 0; i < 107; i++)
        {
            player_f_d >> D[i].First_name >> D[i].Last_name >> D[i].Position >> D[i].Age >> D[i].Team >> D[i].Country >> D[i].No_of_matches >> D[i].Tackles_won >> D[i].Clearance >> D[i].Blocked_shots >> D[i].Red_card >> D[i].Goals >> D[i].Pass_Accuracy;
        }
        cout << "DEFENCE : " << endl
             << endl;
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY" << endl
             << endl;
        for (int i = 0; i < 107; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << D[i].First_name << setw(14) << D[i].Last_name << setw(5) << D[i].Position << setw(4) << D[i].Age << setw(22) << D[i].Team << setw(13) << D[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }
};
//GoalKeeper class (Inherited from Football class --> Will contain all the components of Football as well as its parent class Player)
class GoalKeeper : public Football
{
protected:
public:
    int Clean_sheets;
    int Saves_made;
    int Goals_conceeded;

    GoalKeeper() //Default constructor for Goalkeeper class
    {
        Clean_sheets = 0;
        Saves_made = 0;
        Goals_conceeded = 0;
    }

    //Parameterized Constructor for Goalkeeper class
    GoalKeeper(string first_name, string last_name, int age, string team, string country, int win, int lost, string position, int no_of_matches, int assist, int pass_accuracy, int red_card, int draw, int clean_sheets, int saves_made, int goals_conceeded) : Football(first_name, last_name, age, team, country, win, lost, no_of_matches, position, pass_accuracy, red_card, draw)
    {
        Clean_sheets = clean_sheets;
        Saves_made = saves_made;
        Goals_conceeded = goals_conceeded;
    }

    ~GoalKeeper() {} //Destructor for Goalkeeper class

    void Search_player_f_gk(vector<GoalKeeper>& Gk, string name)
    {
        fstream psearch_gk("gk.txt");
        int id[30];
        int _id = 1;
        for (int i = 0; i < 30; i++)
        {
            id[i] = _id;
            _id++;
        }
        psearch_gk.seekg(0);
        for (int i = 0; i < 27; i++)
        {
            psearch_gk >> Gk[i].First_name >> Gk[i].Last_name >> Gk[i].Position >> Gk[i].Age >> Gk[i].Team >> Gk[i].Country >> Gk[i].No_of_matches >> Gk[i].Clean_sheets >> Gk[i].Saves_made >> Gk[i].Goals_conceeded >> Gk[i].Red_card;
        }

        int check = 0;

        for (int i = 0; i < 27; i++)
        {
            if (name == Gk[i].First_name || name == Gk[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY      App  Cln.S Saves G.Con RCd" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 27; i++)
        {
            if (name == Gk[i].First_name || name == Gk[i].Last_name)
            {
                cout << left << setw(4) << id[i] << setw(10) << Gk[i].First_name << setw(14) << Gk[i].Last_name << setw(5) << Gk[i].Position << setw(4) << Gk[i].Age << setw(22) << Gk[i].Team << setw(13) << Gk[i].Country << setw(5) << Gk[i].No_of_matches << setw(6) << Gk[i].Clean_sheets << setw(6) << Gk[i].Saves_made << setw(6) << Gk[i].Goals_conceeded << setw(3) << Gk[i].Red_card << endl;
                cout << "-----------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Player_display_f_gk(vector<GoalKeeper>& Gk)
    {
        fstream player_f_gk("gk.txt");

        int id[30];
        int _id = 1;
        for (int i = 0; i < 30; i++)
        {
            id[i] = _id;
            _id++;
        }
        player_f_gk.seekg(0);
        for (int i = 0; i < 27; i++)
        {
            player_f_gk >> Gk[i].First_name >> Gk[i].Last_name >> Gk[i].Position >> Gk[i].Age >> Gk[i].Team >> Gk[i].Country >> Gk[i].No_of_matches >> Gk[i].Clean_sheets >> Gk[i].Saves_made >> Gk[i].Goals_conceeded >> Gk[i].Red_card;
        }
        cout << "GOAL-KEEPERS : " << endl
             << endl;
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY" << endl
             << endl;

        for (int i = 0; i < 27; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << Gk[i].First_name << setw(14) << Gk[i].Last_name << setw(5) << Gk[i].Position << setw(4) << Gk[i].Age << setw(22) << Gk[i].Team << setw(13) << Gk[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }

    void Display_stats_f_gk(vector<GoalKeeper>& Gk)
    {
        fstream stats_f_gk("gk.txt");
        int id[30];
        int _id = 1;
        for (int i = 0; i < 30; i++)
        {
            id[i] = _id;
            _id++;
        }

        stats_f_gk.seekg(0);
        for (int i = 0; i < 27; i++)
        {
            stats_f_gk >> Gk[i].First_name >> Gk[i].Last_name >> Gk[i].Position >> Gk[i].Age >> Gk[i].Team >> Gk[i].Country >> Gk[i].No_of_matches >> Gk[i].Clean_sheets >> Gk[i].Saves_made >> Gk[i].Goals_conceeded >> Gk[i].Red_card;
        }
        cout << "SNO F.Name    L.Name        Pos  AGE TEAM                  COUNTRY      App  Cln.S Saves  G.Con  RCd" << endl
             << endl
             << endl;
        for (int i = 0; i < 27; i++)
        {
            cout << left << setw(4) << id[i] << setw(10) << Gk[i].First_name << setw(14) << Gk[i].Last_name << setw(5) << Gk[i].Position << setw(4) << Gk[i].Age << setw(22) << Gk[i].Team << setw(13) << Gk[i].Country << setw(5) << Gk[i].No_of_matches << setw(6) << Gk[i].Clean_sheets << setw(7) << Gk[i].Saves_made << setw(7) << Gk[i].Goals_conceeded << setw(3) << Gk[i].Red_card << endl;
            cout << "-----------------------------------------------------------------------------------------------------" << endl;
        }
    }
};


//Base class for cricket ---> Inherited from class "Player"
class Cricket : public Player
{
protected:
public:
    int Innings;
    int Runs;
    float Batting_strike_rate;
    float Batting_average;
    int Fours;
    int Sixes;
    string Best_Batting_figure;

    Cricket() //Default Constructor for Cricket class
    {
        Innings = 0;
        Runs = 0;
        Batting_strike_rate = 0;
        Batting_average = 0;
        Fours = 0;
        Sixes = 0;
        Best_Batting_figure = "";
    }

    //Parameterized Constructor for Cricket class
    Cricket(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, int innings, int runs, float batting_strike_rate, float batting_average, int fours, int sixes, string best_batting_figure) : Player(first_name, last_name, age, team, country, win, lost, no_of_matches)
    {
        Innings = innings;
        Runs = runs;
        Batting_strike_rate = batting_strike_rate;
        Batting_average = batting_average;
        Fours = fours;
        Sixes = sixes;
        Best_Batting_figure = best_batting_figure;
    }

    ~Cricket() {} //Destructor for Cricket class

    void displaymain() override
    {
        cout << "\t\t\t\t**********************************" << endl;
        cout << "\t\t\t\tWELCOME TO Player ANALYZER PROGRAM" << endl;
        cout << "\t\t\t\t**********************************" << endl
             << endl
             << endl;
        cout << "\t\t\t\t>>>>>>> Welcome to Cricket <<<<<<" << endl
             << endl;
        cout << "\t\t\t\t1. View Teams " << endl;
        cout << "\t\t\t\t2. View Players " << endl;
        cout << "\t\t\t\t3. Stats " << endl;
        cout << "\t\t\t\t4. Standings " << endl;
        cout << "\t\t\t\t5. Return to Main Menu" << endl;
        cout << "\t\t\t\t0. EXIT" << endl
             << endl;
        cout << "\t\t\t\tEnter your Choice: ";
    }

    void Team_display_c() //For diplaying the teams of cricket
    {
        fstream team_c("team_c.txt");
        string c;
        if (!team_c)
            cout << "Error" << endl;
        else
        {
            while (!team_c.eof())
            {
                getline(team_c, c);
                cout << c << endl;
            }
        }
    }

    void Standings_display_c()
    {
        fstream standings_c("standings_c.txt");
        string c;
        if (!standings_c)
            cout << "Error" << endl;
        else
        {
            while (!standings_c.eof())
            {
                getline(standings_c, c);
                cout << c << endl;
            }
        }
    }
};
//Batsman class (Inherited from Cricket class --> Will contain all the components of Cricket as well as its parent class Player)
class Batsman : public Cricket
{
protected:
public:
    int Centuries;
    int Fifties;

    Batsman() //Default constructor for Batsman class
    {
        Centuries = 0;
        Fifties = 0;
    }

    //Parameterized constructor for Batsman class
    Batsman(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, int innings, int runs, float batting_strike_rate, float batting_average, int fours, int sixes, string best_batting_figure, int centuries, int fifties) : Cricket(first_name, last_name, age, team, country, win, lost, no_of_matches, innings, runs, batting_strike_rate, batting_average, fours, sixes, best_batting_figure)
    {
        Centuries = centuries;
        Fifties = fifties;
    }

    ~Batsman() {} //Destructor for Batsman class

    void Player_display_c_bt(vector<Batsman>& Bt) //For displaying the Batsman
    {
        fstream player_c_bt("batsman.txt");
        int id[100];
        player_c_bt.seekg(0);
        for (int i = 0; i < 45; i++)
        {
            player_c_bt >> id[i] >> Bt[i].First_name >> Bt[i].Last_name >> Bt[i].Age >> Bt[i].Team >> Bt[i].Country >> Bt[i].No_of_matches >> Bt[i].Innings >> Bt[i].Runs >> Bt[i].Batting_strike_rate >> Bt[i].Batting_average >> Bt[i].Fifties >> Bt[i].Centuries >> Bt[i].Best_Batting_figure >> Bt[i].Fours >> Bt[i].Sixes;
        }
        cout << "BATSMAN : " << endl
             << endl;
        cout << "F.Name     L.Name      AGE TEAM                        COUNTRY" << endl
             << endl
             << endl;
        for (int i = 0; i < 45; i++)
        {
            cout << left << setw(11) << Bt[i].First_name << setw(12) << Bt[i].Last_name << setw(4) << Bt[i].Age << setw(28) << Bt[i].Team << setw(13) << Bt[i].Country << endl;
            cout << "-------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }

    void Search_player_c_bt(vector<Batsman>& Bt, string name)
    {
        fstream psearch_bt("batsman.txt");
        int id[50];
        psearch_bt.seekg(0);
        for (int i = 0; i < 45; i++)
        {
            psearch_bt >> id[i] >> Bt[i].First_name >> Bt[i].Last_name >> Bt[i].Age >> Bt[i].Team >> Bt[i].Country >> Bt[i].No_of_matches >> Bt[i].Innings >> Bt[i].Runs >> Bt[i].Batting_strike_rate >> Bt[i].Batting_average >> Bt[i].Fifties >> Bt[i].Centuries >> Bt[i].Best_Batting_figure >> Bt[i].Fours >> Bt[i].Sixes;
        }

        int check = 0;

        for (int i = 0; i < 45; i++)
        {
            if (name == Bt[i].First_name || name == Bt[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "F.Name     L.Name      AGE TEAM                        COUNTRY      TM INN RUNS S.R.   Avg   50s  100s Best 4s 6s" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 45; i++)
        {
            if (name == Bt[i].First_name || name == Bt[i].Last_name)
            {
                cout << left << setw(11) << Bt[i].First_name << setw(12) << Bt[i].Last_name << setw(4) << Bt[i].Age << setw(28) << Bt[i].Team << setw(13) << Bt[i].Country << setw(3) << Bt[i].No_of_matches << setw(4) << Bt[i].Innings << setw(5) << Bt[i].Runs << setw(7) << Bt[i].Batting_strike_rate << setw(6) << Bt[i].Batting_average << setw(5) << Bt[i].Fifties << setw(5) << Bt[i].Centuries << setw(5) << Bt[i].Best_Batting_figure << setw(3) << Bt[i].Fours << setw(3) << Bt[i].Sixes << endl;
                cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Display_stats_c_bt(vector<Batsman>& Bt)
    {
        fstream stats_c_bt("batsman.txt");
        int id[50];

        stats_c_bt.seekg(0);
        for (int i = 0; i < 45; i++)
        {
            stats_c_bt >> id[i] >> Bt[i].First_name >> Bt[i].Last_name >> Bt[i].Age >> Bt[i].Team >> Bt[i].Country >> Bt[i].No_of_matches >> Bt[i].Innings >> Bt[i].Runs >> Bt[i].Batting_strike_rate >> Bt[i].Batting_average >> Bt[i].Fifties >> Bt[i].Centuries >> Bt[i].Best_Batting_figure >> Bt[i].Fours >> Bt[i].Sixes;
        }
        cout << "SNO F.Name     L.Name      AGE TEAM                        COUNTRY      TM INN RUNS S.R.   Avg   50s  100s Best 4s 6s" << endl
             << endl
             << endl;
        for (int i = 0; i < 45; i++)
        {
            cout << left << setw(4) << id[i] << setw(11) << Bt[i].First_name << setw(12) << Bt[i].Last_name << setw(4) << Bt[i].Age << setw(28) << Bt[i].Team << setw(13) << Bt[i].Country << setw(3) << Bt[i].No_of_matches << setw(4) << Bt[i].Innings << setw(5) << Bt[i].Runs << setw(7) << Bt[i].Batting_strike_rate << setw(6) << Bt[i].Batting_average << setw(5) << Bt[i].Fifties << setw(5) << Bt[i].Centuries << setw(5) << Bt[i].Best_Batting_figure << setw(4) << Bt[i].Fours << setw(3) << Bt[i].Sixes << endl;
            cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
        }
    }
};
//Bowler class (Inherited from Cricket class --> Will contain all the components of Cricket as well as its parent class Player)
class Bowler : public Cricket
{
protected:
public:
    int Wickets;
    float Bowling_average;
    int Four_wkt_hauls;
    float Economy;
    string Best_Bowling_figure;

    Bowler() //Default Constructor for Bowler class
    {
        Wickets = 0;
        Bowling_average = 0;
        Four_wkt_hauls = 0;
        Economy = 0;
        Best_Bowling_figure = "";
    }

    // Parameterized Constructor for Bowler class
    Bowler(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, int innings, int runs, float batting_strike_rate, float batting_average, int fours, int sixes, string best_batting_figure, int wickets, float bowling_average, int four_wkt_haul, float economy, string best_bowling_figure) : Cricket(first_name, last_name, age, team, country, win, lost, no_of_matches, innings, runs, batting_strike_rate, batting_average, fours, sixes, best_batting_figure)
    {
        Wickets = wickets;
        Bowling_average = bowling_average;
        Four_wkt_hauls = four_wkt_haul;
        Economy = economy;
        Best_Bowling_figure = best_bowling_figure;
    }

    ~Bowler() {} //Destructor for Bowler class

    void Player_display_c_bo(vector<Bowler>& Bo) //For displaying the Bowlers
    {
        fstream player_c_bo("bowlers.txt");
        int id[100];
        player_c_bo.seekg(0);
        for (int i = 0; i < 53; i++)
        {
            player_c_bo >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
        }
        cout << "BOWLERS : " << endl
             << endl;
        cout << "F.Name       L.Name        AGE TEAM                        COUNTRY" << endl
             << endl
             << endl;
        for (int i = 0; i < 53; i++)
        {
            cout << left << setw(13) << Bo[i].First_name << setw(14) << Bo[i].Last_name << setw(4) << Bo[i].Age << setw(28) << Bo[i].Team << setw(13) << Bo[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }

    void Search_player_c_bo(vector<Bowler>& Bo, string name)
    {
        fstream psearch_bo("bowlers.txt");
        int id[60];
        psearch_bo.seekg(0);
        for (int i = 0; i < 53; i++)
        {
            psearch_bo >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
        }

        int check = 0;

        for (int i = 0; i < 53; i++)
        {
            if (name == Bo[i].First_name || name == Bo[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN W   ECO   Avg   Best 4WH RUNS S.R.   Avg   Best 4s  6s" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 53; i++)
        {
            if (name == Bo[i].First_name || name == Bo[i].Last_name)
            {
                cout << left << setw(13) << Bo[i].First_name << setw(14) << Bo[i].Last_name << setw(4) << Bo[i].Age << setw(28) << Bo[i].Team << setw(13) << Bo[i].Country << setw(3) << Bo[i].No_of_matches << setw(4) << Bo[i].Innings << setw(4) << Bo[i].Wickets << setw(6) << Bo[i].Economy << setw(6) << Bo[i].Bowling_average << setw(5) << Bo[i].Best_Bowling_figure << setw(4) << Bo[i].Four_wkt_hauls << setw(5) << Bo[i].Runs << setw(7) << Bo[i].Batting_strike_rate << setw(6) << Bo[i].Batting_average << setw(5) << Bo[i].Best_Batting_figure << setw(4) << Bo[i].Fours << setw(3) << Bo[i].Sixes << endl;
                cout << "-----------------------------------------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Display_stats_c_bo(vector<Bowler>& Bo)
    {
        fstream stats_c_bo("bowlers.txt");
        int id[60];

        stats_c_bo.seekg(0);
        for (int i = 0; i < 53; i++)
        {
            stats_c_bo >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
        }
        cout << "SNO F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN W   ECO   Avg   Best 4WH RUNS S.R.   Avg   Best 4s  6s" << endl
             << endl
             << endl;
        for (int i = 0; i < 53; i++)
        {
            cout << left << setw(4) << id[i] << setw(13) << Bo[i].First_name << setw(14) << Bo[i].Last_name << setw(4) << Bo[i].Age << setw(28) << Bo[i].Team << setw(13) << Bo[i].Country << setw(3) << Bo[i].No_of_matches << setw(4) << Bo[i].Innings << setw(4) << Bo[i].Wickets << setw(6) << Bo[i].Economy << setw(6) << Bo[i].Bowling_average << setw(5) << Bo[i].Best_Bowling_figure << setw(4) << Bo[i].Four_wkt_hauls << setw(5) << Bo[i].Runs << setw(7) << Bo[i].Batting_strike_rate << setw(6) << Bo[i].Batting_average << setw(5) << Bo[i].Best_Batting_figure << setw(4) << Bo[i].Fours << setw(3) << Bo[i].Sixes << endl;
            cout << "-----------------------------------------------------------------------------------------------------------------------------------------" << endl;
        }
    }
};
//All-Rounder class (Inherited from Cricket class --> Will contain all the components of Cricket as well as its parent class Player)
class All_rounder : public Cricket
{
protected:
public:
    int Centuries;
    int Fifties;
    int Wickets;
    float Bowling_average;
    int Four_wkt_hauls;
    float Economy;
    string Best_Bowling_figure;

    All_rounder() //Default constructor for All_rounder class
    {
        Centuries = 0;
        Fifties = 0;
        Wickets = 0;
        Bowling_average = 0;
        Four_wkt_hauls = 0;
        Economy = 0;
        Best_Bowling_figure = "";
    }

    //Parameterized constructor for All_rounder class
    All_rounder(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, int innings, int runs, float batting_strike_rate, float batting_average, int fours, int sixes, string best_batting_figure, int centuries, int fifties, int wickets, float bowling_average, int four_wkt_hauls, float economy, string best_bowling_figure) : Cricket(first_name, last_name, age, team, country, win, lost, no_of_matches, innings, runs, batting_strike_rate, batting_average, fours, sixes, best_batting_figure)
    {
        Centuries = centuries;
        Fifties = fifties;
        Wickets = wickets;
        Bowling_average = bowling_average;
        Four_wkt_hauls = four_wkt_hauls;
        Economy = economy;
        Best_Bowling_figure = best_bowling_figure;
    }

    ~All_rounder() {} //Destructor for All_rounder class

    void Player_display_c_ar(vector<All_rounder>& Ar) //For displaying the All-rounders
    {
        fstream player_c_ar("all_rounders.txt");
        int id[100];
        player_c_ar.seekg(0);
        for (int i = 0; i < 30; i++)
        {
            player_c_ar >> id[i] >> Ar[i].First_name >> Ar[i].Last_name >> Ar[i].Age >> Ar[i].Team >> Ar[i].Country >> Ar[i].No_of_matches >> Ar[i].Innings >> Ar[i].Runs >> Ar[i].Batting_strike_rate >> Ar[i].Batting_average >> Ar[i].Fifties >> Ar[i].Centuries >> Ar[i].Best_Batting_figure >> Ar[i].Fours >> Ar[i].Sixes >> Ar[i].Wickets >> Ar[i].Economy >> Ar[i].Bowling_average >> Ar[i].Best_Bowling_figure >> Ar[i].Four_wkt_hauls;
        }
        cout << "ALL-ROUNDERS : " << endl
             << endl;
        cout << "F.Name       L.Name        AGE TEAM                        COUNTRY" << endl
             << endl
             << endl;
        for (int i = 0; i < 30; i++)
        {
            cout << left << setw(13) << Ar[i].First_name << setw(14) << Ar[i].Last_name << setw(4) << Ar[i].Age << setw(28) << Ar[i].Team << setw(13) << Ar[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }

    void Search_player_c_ar(vector<All_rounder>& Ar, string name)
    {
        fstream psearch_ar("all_rounders.txt");
        int id[50];
        psearch_ar.seekg(0);
        for (int i = 0; i < 30; i++)
        {
            psearch_ar >> id[i] >> Ar[i].First_name >> Ar[i].Last_name >> Ar[i].Age >> Ar[i].Team >> Ar[i].Country >> Ar[i].No_of_matches >> Ar[i].Innings >> Ar[i].Runs >> Ar[i].Batting_strike_rate >> Ar[i].Batting_average >> Ar[i].Fifties >> Ar[i].Centuries >> Ar[i].Best_Batting_figure >> Ar[i].Fours >> Ar[i].Sixes >> Ar[i].Wickets >> Ar[i].Economy >> Ar[i].Bowling_average >> Ar[i].Best_Bowling_figure >> Ar[i].Four_wkt_hauls;
        }

        int check = 0;

        for (int i = 0; i < 30; i++)
        {
            if (name == Ar[i].First_name || name == Ar[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN RUNS S.R.   Avg   50s 100s Best 4s  6s W   ECO   Avg   Best 4WH" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 30; i++)
        {
            if (name == Ar[i].First_name || name == Ar[i].Last_name)
            {
                cout << left << setw(13) << Ar[i].First_name << setw(14) << Ar[i].Last_name << setw(4) << Ar[i].Age << setw(28) << Ar[i].Team << setw(13) << Ar[i].Country << setw(3) << Ar[i].No_of_matches << setw(4) << Ar[i].Innings << setw(5) << Ar[i].Runs << setw(7) << Ar[i].Batting_strike_rate << setw(6) << Ar[i].Batting_average << setw(4) << Ar[i].Fifties << setw(5) << Ar[i].Centuries << setw(5) << Ar[i].Best_Batting_figure << setw(4) << Ar[i].Fours << setw(3) << Ar[i].Sixes << setw(4) << Ar[i].Wickets << setw(6) << Ar[i].Economy << setw(6) << Ar[i].Bowling_average << setw(5) << Ar[i].Best_Bowling_figure << setw(4) << Ar[i].Four_wkt_hauls << endl;
                cout << "--------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Display_stats_c_ar(vector<All_rounder>& Ar)
    {
        fstream stats_c_ar("all_rounders.txt");
        int id[30];

        stats_c_ar.seekg(0);
        for (int i = 0; i < 30; i++)
        {
            stats_c_ar >> id[i] >> Ar[i].First_name >> Ar[i].Last_name >> Ar[i].Age >> Ar[i].Team >> Ar[i].Country >> Ar[i].No_of_matches >> Ar[i].Innings >> Ar[i].Runs >> Ar[i].Batting_strike_rate >> Ar[i].Batting_average >> Ar[i].Fifties >> Ar[i].Centuries >> Ar[i].Best_Batting_figure >> Ar[i].Fours >> Ar[i].Sixes >> Ar[i].Wickets >> Ar[i].Economy >> Ar[i].Bowling_average >> Ar[i].Best_Bowling_figure >> Ar[i].Four_wkt_hauls;
        }
        cout << "SNO F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN RUNS S.R.   Avg   50s 100s Best 4s  6s W   ECO   Avg   Best 4WH" << endl
             << endl
             << endl;
        for (int i = 0; i < 30; i++)
        {
            cout << left << setw(4) << id[i] << setw(13) << Ar[i].First_name << setw(14) << Ar[i].Last_name << setw(4) << Ar[i].Age << setw(28) << Ar[i].Team << setw(13) << Ar[i].Country << setw(3) << Ar[i].No_of_matches << setw(4) << Ar[i].Innings << setw(5) << Ar[i].Runs << setw(7) << Ar[i].Batting_strike_rate << setw(6) << Ar[i].Batting_average << setw(4) << Ar[i].Fifties << setw(5) << Ar[i].Centuries << setw(5) << Ar[i].Best_Batting_figure << setw(4) << Ar[i].Fours << setw(3) << Ar[i].Sixes << setw(4) << Ar[i].Wickets << setw(6) << Ar[i].Economy << setw(6) << Ar[i].Bowling_average << setw(5) << Ar[i].Best_Bowling_figure << setw(4) << Ar[i].Four_wkt_hauls << endl;
            cout << "--------------------------------------------------------------------------------------------------------------------------------------------------" << endl;
        }
    }
};
//Wicket-Keeper class (Inherited from Cricket class --> Will contain all the components of Cricket as well as its parent class Player)
class Wicket_keeper : public Cricket
{
protected:
public:
    int Centuries;
    int Fifties;
    int Stumps;
    int Catches;

    Wicket_keeper() //Default Constructor for Wicket_keeper class;
    {
        Centuries = 0;
        Fifties = 0;
        Stumps = 0;
        Catches = 0;
    }

    //Parameterized constructor for Wicket_keeper class
    Wicket_keeper(string first_name, string last_name, int age, string team, string country, int win, int lost, int no_of_matches, int innings, int runs, float batting_strike_rate, float batting_average, int fours, int sixes, string best_batting_figure, int centuries, int fifties, int stumps, int catches) : Cricket(first_name, last_name, age, team, country, win, lost, no_of_matches, innings, runs, batting_strike_rate, batting_average, fours, sixes, best_batting_figure)
    {
        Centuries = centuries;
        Fifties = fifties;
        Stumps = stumps;
        Catches = catches;
    }

    void Player_display_c_wk(vector<Wicket_keeper>& Wk) //For displaying the wicket-keepers
    {
        fstream player_c_wk("WICKETKEEPERS.txt");
        player_c_wk.seekg(0);

        int id[100];

        for (int i = 0; i < 8; i++) //Reading WICKETKEEPERS.txt file in the object
        {
            player_c_wk >> id[i] >> Wk[i].First_name >> Wk[i].Last_name >> Wk[i].Age >> Wk[i].Team >> Wk[i].Country >> Wk[i].No_of_matches >> Wk[i].Innings >> Wk[i].Stumps >> Wk[i].Catches >> Wk[i].Runs >> Wk[i].Batting_strike_rate >> Wk[i].Batting_average >> Wk[i].Fifties >> Wk[i].Centuries >> Wk[i].Best_Batting_figure >> Wk[i].Fours >> Wk[i].Sixes;
        }

        cout << "WICKET-KEEPERS : " << endl
             << endl;
        cout << "F.Name       L.Name        AGE TEAM                        COUNTRY" << endl
             << endl
             << endl;

        for (int i = 0; i < 8; i++) //Displaying all wicketkeepers from the file
        {
            cout << left << setw(13) << Wk[i].First_name << setw(14) << Wk[i].Last_name << setw(4) << Wk[i].Age << setw(28) << Wk[i].Team << setw(13) << Wk[i].Country << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }
        cout << endl;
    }

    void Search_player_c_wk(vector<Wicket_keeper>& Wk, string name) //For searching a specific player from the file via First Name search
    {
        fstream psearch_wk("WICKETKEEPERS.txt");
        int id[10];

        psearch_wk.seekg(0);

        for (int i = 0; i < 8; i++) //Reading WICKETKEEPERS.txt file in the object
        {
            psearch_wk >> id[i] >> Wk[i].First_name >> Wk[i].Last_name >> Wk[i].Age >> Wk[i].Team >> Wk[i].Country >> Wk[i].No_of_matches >> Wk[i].Innings >> Wk[i].Stumps >> Wk[i].Catches >> Wk[i].Runs >> Wk[i].Batting_strike_rate >> Wk[i].Batting_average >> Wk[i].Fifties >> Wk[i].Centuries >> Wk[i].Best_Batting_figure >> Wk[i].Fours >> Wk[i].Sixes;
        }

        int check = 0;

        for (int i = 0; i < 8; i++)
        {
            if (name == Wk[i].First_name || name == Wk[i].Last_name)
            {
                check = 1;
            }
        }

        if (check == 1)
        {
            cout << "F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN C   St  RUNS S.R.   Avg   50s 100s Best 4s  6s" << endl
                 << endl
                 << endl;
        }
        else
        {
            cout << "This player does not exist" << endl
                 << endl;
        }

        for (int i = 0; i < 8; i++)
        {
            if (name == Wk[i].First_name || name == Wk[i].Last_name) //Checking and printing the required Wicket-keeper's Data
            {
                cout << left << setw(13) << Wk[i].First_name << setw(14) << Wk[i].Last_name << setw(4) << Wk[i].Age << setw(28) << Wk[i].Team << setw(13) << Wk[i].Country << setw(3) << Wk[i].No_of_matches << setw(4) << Wk[i].Innings << setw(4) << Wk[i].Stumps << setw(4) << Wk[i].Catches << setw(5) << Wk[i].Runs << setw(7) << Wk[i].Batting_strike_rate << setw(6) << Wk[i].Batting_average << setw(4) << Wk[i].Fifties << setw(5) << Wk[i].Centuries << setw(5) << Wk[i].Best_Batting_figure << setw(4) << Wk[i].Fours << setw(3) << Wk[i].Sixes << endl;
                cout << "-----------------------------------------------------------------------------------------------------------------------------------" << endl;
            }
        }
    }

    void Display_stats_c_wk(vector<Wicket_keeper>& Wk)
    {
        fstream stats_c_wk("WICKETKEEPERS.txt");
        int id[10];

        stats_c_wk.seekg(0);
        for (int i = 0; i < 8; i++)
        {
            stats_c_wk >> id[i] >> Wk[i].First_name >> Wk[i].Last_name >> Wk[i].Age >> Wk[i].Team >> Wk[i].Country >> Wk[i].No_of_matches >> Wk[i].Innings >> Wk[i].Stumps >> Wk[i].Catches >> Wk[i].Runs >> Wk[i].Batting_strike_rate >> Wk[i].Batting_average >> Wk[i].Fifties >> Wk[i].Centuries >> Wk[i].Best_Batting_figure >> Wk[i].Fours >> Wk[i].Sixes;
        }
        cout << "SNO F.Name       L.Name        AGE TEAM                        COUNTRY      TM INN C   St  RUNS S.R.   Avg   50s 100s Best 4s  6s" << endl
             << endl
             << endl;
        for (int i = 0; i < 8; i++)
        {
            cout << left << setw(4) << id[i] << setw(13) << Wk[i].First_name << setw(14) << Wk[i].Last_name << setw(4) << Wk[i].Age << setw(28) << Wk[i].Team << setw(13) << Wk[i].Country << setw(3) << Wk[i].No_of_matches << setw(4) << Wk[i].Innings << setw(4) << Wk[i].Stumps << setw(4) << Wk[i].Catches << setw(5) << Wk[i].Runs << setw(7) << Wk[i].Batting_strike_rate << setw(6) << Wk[i].Batting_average << setw(4) << Wk[i].Fifties << setw(5) << Wk[i].Centuries << setw(5) << Wk[i].Best_Batting_figure << setw(4) << Wk[i].Fours << setw(3) << Wk[i].Sixes << endl;
            cout << "-----------------------------------------------------------------------------------------------------------------------------------" << endl;
        }
    }
};

void Display_top10_run(vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    // Open files for reading data
    fstream bat("batsman.txt"), bowl("bowlers.txt"), allrounder("all_rounders.txt"), wktkeeper("WICKETKEEPERS.txt");

    // Check if files are successfully opened
    if (!bat.is_open()) {
        cout << "Error: Unable to open batsman.txt file!" << endl;
        return;
    }
    if (!bowl.is_open()) {
        cout << "Error: Unable to open bowlers.txt file!" << endl;
        return;
    }
    if (!allrounder.is_open()) {
        cout << "Error: Unable to open all_rounders.txt file!" << endl;
        return;
    }
    if (!wktkeeper.is_open()) {
        cout << "Error: Unable to open WICKETKEEPERS.txt file!" << endl;
        return;
    }

    // Vector to store all players' runs and details
    vector<pair<int, string>> players;

    // Read data for batsmen
    while (!bat.eof()) {
        Batsman b;
        bat >> b.First_name >> b.Last_name >> b.Age >> b.Team >> b.Country >> b.No_of_matches >> b.Innings >> b.Runs;
        players.push_back({b.Runs, b.First_name + " " + b.Last_name + " (" + b.Team + ")"});
    }

    // Read data for bowlers
    while (!bowl.eof()) {
        Bowler b;
        bowl >> b.First_name >> b.Last_name >> b.Age >> b.Team >> b.Country >> b.No_of_matches >> b.Innings >> b.Runs;
        players.push_back({b.Runs, b.First_name + " " + b.Last_name + " (" + b.Team + ")"});
    }

    // Read data for all-rounders
    while (!allrounder.eof()) {
        All_rounder ar;
        allrounder >> ar.First_name >> ar.Last_name >> ar.Age >> ar.Team >> ar.Country >> ar.No_of_matches >> ar.Innings >> ar.Runs;
        players.push_back({ar.Runs, ar.First_name + " " + ar.Last_name + " (" + ar.Team + ")"});
    }

    // Read data for wicket-keepers
    while (!wktkeeper.eof()) {
        Wicket_keeper wk;
        wktkeeper >> wk.First_name >> wk.Last_name >> wk.Age >> wk.Team >> wk.Country >> wk.No_of_matches >> wk.Innings >> wk.Runs;
        players.push_back({wk.Runs, wk.First_name + " " + wk.Last_name + " (" + wk.Team + ")"});
    }

    // Sort players by runs in descending order
     for (size_t i = 0; i < players.size() - 1; ++i) {
        for (size_t j = 0; j < players.size() - i - 1; ++j) {
            if (players[j].first < players[j + 1].first) {
                swap(players[j], players[j + 1]);
            }
        }
    }


    // Display the top 10 players
    cout << "SNo  Runs  Player (Team)" << endl;
    cout << "-------------------------" << endl;

    for (size_t i = 0; i < min(players.size(), size_t(10)); ++i) {
        cout << left << setw(4) << (i + 1) << setw(6) << players[i].first << players[i].second << endl;
    }
}

void Display_top10_strikerate(vector<Batsman>& Bt, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk)
{
    fstream bat("batsman.txt"), allrounder("all_rounders.txt"), wktkeeper("WICKETKEEPERS.txt");

    if (!bat.is_open() || !allrounder.is_open() || !wktkeeper.is_open()) {
        cout << "Error opening one or more files!" << endl;
        return;
    }

    vector<pair<float, string>> players;

    while (!bat.eof()) {
        Batsman b;
        bat >> b.First_name >> b.Last_name >> b.Age >> b.Team >> b.Country >> b.No_of_matches >> b.Innings >> b.Runs >> b.Batting_strike_rate >> b.Batting_average >> b.Fifties >> b.Centuries >> b.Best_Batting_figure >> b.Fours >> b.Sixes;
        players.push_back({b.Batting_strike_rate, b.First_name + " " + b.Last_name + " (" + b.Team + ")"});
    }

    while (!allrounder.eof()) {
        All_rounder ar;
        allrounder >> ar.First_name >> ar.Last_name >> ar.Age >> ar.Team >> ar.Country >> ar.No_of_matches >> ar.Innings >> ar.Runs >> ar.Batting_strike_rate >> ar.Batting_average >> ar.Fifties >> ar.Centuries >> ar.Best_Batting_figure >> ar.Fours >> ar.Sixes >> ar.Wickets >> ar.Economy >> ar.Bowling_average >> ar.Best_Bowling_figure >> ar.Four_wkt_hauls;
        players.push_back({ar.Batting_strike_rate, ar.First_name + " " + ar.Last_name + " (" + ar.Team + ")"});
    }

    while (!wktkeeper.eof()) {
        Wicket_keeper wk;
        wktkeeper >> wk.First_name >> wk.Last_name >> wk.Age >> wk.Team >> wk.Country >> wk.No_of_matches >> wk.Innings >> wk.Stumps >> wk.Catches >> wk.Runs >> wk.Batting_strike_rate >> wk.Batting_average >> wk.Fifties >> wk.Centuries >> wk.Best_Batting_figure >> wk.Fours >> wk.Sixes;
        players.push_back({wk.Batting_strike_rate, wk.First_name + " " + wk.Last_name + " (" + wk.Team + ")"});
    }
// Sort players by strike rate in descending order
    for (size_t i = 0; i < players.size() - 1; ++i) {
        for (size_t j = 0; j < players.size() - i - 1; ++j) {
            if (players[j].first < players[j + 1].first) { 
                swap(players[j], players[j + 1]);
            }
        }
    }


    cout << "SNo  Strike Rate  Player (Team)" << endl;
    cout << "-------------------------------" << endl;

    for (size_t i = 0; i < min(players.size(), size_t(10)); ++i) {
        cout << left << setw(4) << (i + 1) << setw(13) << players[i].first << players[i].second << endl;
    }
}
void Display_top10_batavg(vector<Batsman>& Bt, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk)
{
    fstream bat("batsman.txt");
    if (!bat)
        cout << "Error opening the file!!" << endl;
    fstream allrounder("all_rounders.txt");
    if (!allrounder)
        cout << "Error opening the file!!" << endl;
    fstream wktkeeper("WICKETKEEPERS.txt");
    if (!wktkeeper)
        cout << "Error opening the file!!" << endl;

    int id[83];
    bat.seekg(0);
    allrounder.seekg(0);
    wktkeeper.seekg(0);

    for (int i = 0; i < 45; i++)
    {
        bat >> id[i] >> Bt[i].First_name >> Bt[i].Last_name >> Bt[i].Age >> Bt[i].Team >> Bt[i].Country >> Bt[i].No_of_matches >> Bt[i].Innings >> Bt[i].Runs >> Bt[i].Batting_strike_rate >> Bt[i].Batting_average >> Bt[i].Fifties >> Bt[i].Centuries >> Bt[i].Best_Batting_figure >> Bt[i].Fours >> Bt[i].Sixes;
    }
    for (int i = 45; i < 75; i++)
    {
        allrounder >> id[i] >> Ar[i - 45].First_name >> Ar[i - 45].Last_name >> Ar[i - 45].Age >> Ar[i - 45].Team >> Ar[i - 45].Country >> Ar[i - 45].No_of_matches >> Ar[i - 45].Innings >> Ar[i - 45].Runs >> Ar[i - 45].Batting_strike_rate >> Ar[i - 45].Batting_average >> Ar[i - 45].Fifties >> Ar[i - 45].Centuries >> Ar[i - 45].Best_Batting_figure >> Ar[i - 45].Fours >> Ar[i - 45].Sixes >> Ar[i - 45].Wickets >> Ar[i - 45].Economy >> Ar[i - 45].Bowling_average >> Ar[i - 45].Best_Bowling_figure >> Ar[i - 45].Four_wkt_hauls;
    }
    for (int i = 75; i < 83; i++)
    {
        wktkeeper >> id[i] >> Wk[i - 75].First_name >> Wk[i - 75].Last_name >> Wk[i - 75].Age >> Wk[i - 75].Team >> Wk[i - 75].Country >> Wk[i - 75].No_of_matches >> Wk[i - 75].Innings >> Wk[i - 75].Stumps >> Wk[i - 75].Catches >> Wk[i - 75].Runs >> Wk[i - 75].Batting_strike_rate >> Wk[i - 75].Batting_average >> Wk[i - 75].Fifties >> Wk[i - 75].Centuries >> Wk[i - 75].Best_Batting_figure >> Wk[i - 75].Fours >> Wk[i - 75].Sixes;
    }

    float batavg[83];
    for (int i = 0; i < 45; i++)
        batavg[i] = Bt[i].Batting_average;

    for (int i = 45; i < 75; i++)
        batavg[i] = Ar[i - 45].Batting_average;

    for (int i = 75; i < 83; i++)
        batavg[i] = Wk[i - 75].Batting_average;

    int n = sizeof(batavg) / sizeof(batavg[0]);
    sort(batavg, batavg + n, greater<int>());

    int n1 = 83;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (batavg[i] == batavg[j]) //checks for multiple instances of same runs
            {
                for (int k = j; k < n1 - 1; ++k)
                    batavg[k] = batavg[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo  F.Name     L.Name       TEAM                        TM   Bat Avg" << endl
         << endl
         << endl;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 45; j++)
        {
            if (batavg[i] == Bt[j].Batting_average) // checks where the given (batavg) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Bt[j].First_name << setw(13) << Bt[j].Last_name << setw(28) << Bt[j].Team << setw(5) << Bt[j].No_of_matches << setw(5) << Bt[j].Batting_average << endl;
                cout << "---------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 30; j++)
        {
            if (batavg[i] == Ar[j].Batting_average) // checks where the given (batavg) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Ar[j].First_name << setw(13) << Ar[j].Last_name << setw(28) << Ar[j].Team << setw(5) << Ar[j].No_of_matches << setw(5) << Ar[j].Batting_average << endl;
                cout << "---------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 8; j++)
        {
            if (batavg[i] == Wk[j].Batting_average) // checks where the given (batavg) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Wk[j].First_name << setw(13) << Wk[j].Last_name << setw(28) << Wk[j].Team << setw(5) << Wk[j].No_of_matches << setw(5) << Wk[j].Batting_average << endl;
                cout << "---------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_wkt(vector<Bowler>& Bo, vector<All_rounder>& Ar)
{
    fstream bowl("bowlers.txt");
    if (!bowl)
        cout << "Error opening the file!!" << endl;
    fstream allrounder("all_rounders.txt");
    if (!allrounder)
        cout << "Error opening the file!!" << endl;

    int id[83];
    bowl.seekg(0);
    allrounder.seekg(0);

    for (int i = 0; i < 53; i++)
    {
        bowl >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
    }
    for (int i = 53; i < 83; i++)
    {
        allrounder >> id[i] >> Ar[i - 53].First_name >> Ar[i - 53].Last_name >> Ar[i - 53].Age >> Ar[i - 53].Team >> Ar[i - 53].Country >> Ar[i - 53].No_of_matches >> Ar[i - 53].Innings >> Ar[i - 53].Runs >> Ar[i - 53].Batting_strike_rate >> Ar[i - 53].Batting_average >> Ar[i - 53].Fifties >> Ar[i - 53].Centuries >> Ar[i - 53].Best_Batting_figure >> Ar[i - 53].Fours >> Ar[i - 53].Sixes >> Ar[i - 53].Wickets >> Ar[i - 53].Economy >> Ar[i - 53].Bowling_average >> Ar[i - 53].Best_Bowling_figure >> Ar[i - 53].Four_wkt_hauls;
    }

    int wkts[83];
    for (int i = 0; i < 53; i++)
        wkts[i] = Bo[i].Wickets;

    for (int i = 53; i < 83; i++)
        wkts[i] = Ar[i - 53].Wickets;

    int n = sizeof(wkts) / sizeof(wkts[0]);
    sort(wkts, wkts + n, greater<int>());

    int n1 = 83;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (wkts[i] == wkts[j]) //checks for multiple instances of same runs
            {
                for (int k = j; k < n1 - 1; ++k)
                    wkts[k] = wkts[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo  F.Name     L.Name       TEAM                        TM    Wkt" << endl
         << endl
         << endl;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 53; j++)
        {
            if (wkts[i] == Bo[j].Wickets) // checks where the given (wkts) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Bo[j].First_name << setw(14) << Bo[j].Last_name << setw(28) << Bo[j].Team << setw(5) << Bo[j].No_of_matches << setw(5) << Bo[j].Wickets << endl;
                cout << "------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 30; j++)
        {
            if (wkts[i] == Ar[j].Wickets) // checks where the given (wkts) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Ar[j].First_name << setw(14) << Ar[j].Last_name << setw(28) << Ar[j].Team << setw(5) << Ar[j].No_of_matches << setw(5) << Ar[j].Wickets << endl;
                cout << "------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_bowlavg(vector<Bowler>& Bo, vector<All_rounder>& Ar)
{
    fstream bowl("bowlers.txt");
    if (!bowl)
        cout << "Error opening the file!!" << endl;
    fstream allrounder("all_rounders.txt");
    if (!allrounder)
        cout << "Error opening the file!!" << endl;

    int id[83];
    bowl.seekg(0);
    allrounder.seekg(0);

    for (int i = 0; i < 53; i++)
    {
        bowl >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
    }
    for (int i = 53; i < 83; i++)
    {
        allrounder >> id[i] >> Ar[i - 53].First_name >> Ar[i - 53].Last_name >> Ar[i - 53].Age >> Ar[i - 53].Team >> Ar[i - 53].Country >> Ar[i - 53].No_of_matches >> Ar[i - 53].Innings >> Ar[i - 53].Runs >> Ar[i - 53].Batting_strike_rate >> Ar[i - 53].Batting_average >> Ar[i - 53].Fifties >> Ar[i - 53].Centuries >> Ar[i - 53].Best_Batting_figure >> Ar[i - 53].Fours >> Ar[i - 53].Sixes >> Ar[i - 53].Wickets >> Ar[i - 53].Economy >> Ar[i - 53].Bowling_average >> Ar[i - 53].Best_Bowling_figure >> Ar[i - 53].Four_wkt_hauls;
    }

    float bowlavg[83];
    for (int i = 0; i < 53; i++)
        bowlavg[i] = Bo[i].Bowling_average;

    for (int i = 53; i < 83; i++)
        bowlavg[i] = Ar[i - 53].Bowling_average;

    int tot = 83;
    for (int i = 0; i < tot; i++)
    {
        if (bowlavg[i] == 0)
        {
            for (int j = i; j < (tot - 1); j++)
                bowlavg[j] = bowlavg[j + 1];
            i--;
            tot--;
        }
    }

    int n = sizeof(bowlavg) / sizeof(bowlavg[0]);
    sort(bowlavg, bowlavg + n);

    int n1 = 83;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (bowlavg[i] == bowlavg[j]) //checks for multiple instances of same runs
            {
                for (int k = j; k < n1 - 1; ++k)
                    bowlavg[k] = bowlavg[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo  F.Name     L.Name       TEAM                        TM    Bowl Avg" << endl
         << endl
         << endl;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 53; j++)
        {
            if (bowlavg[i] == Bo[j].Bowling_average) // checks where the given (bowlavg) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Bo[j].First_name << setw(14) << Bo[j].Last_name << setw(28) << Bo[j].Team << setw(5) << Bo[j].No_of_matches << setw(5) << Bo[j].Bowling_average << endl;
                cout << "-----------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 30; j++)
        {
            if (bowlavg[i] == Ar[j].Bowling_average) // checks where the given (bowlavg) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Ar[j].First_name << setw(14) << Ar[j].Last_name << setw(28) << Ar[j].Team << setw(5) << Ar[j].No_of_matches << setw(5) << Ar[j].Bowling_average << endl;
                cout << "-----------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_eco(vector<Bowler>& Bo, vector<All_rounder>& Ar)
{
    fstream bowl("bowlers.txt");
    if (!bowl)
        cout << "Error opening the file!!" << endl;
    fstream allrounder("all_rounders.txt");
    if (!allrounder)
        cout << "Error opening the file!!" << endl;

    int id[83];
    bowl.seekg(0);
    allrounder.seekg(0);

    for (int i = 0; i < 53; i++)
    {
        bowl >> id[i] >> Bo[i].First_name >> Bo[i].Last_name >> Bo[i].Age >> Bo[i].Team >> Bo[i].Country >> Bo[i].No_of_matches >> Bo[i].Innings >> Bo[i].Wickets >> Bo[i].Economy >> Bo[i].Bowling_average >> Bo[i].Best_Bowling_figure >> Bo[i].Four_wkt_hauls >> Bo[i].Runs >> Bo[i].Batting_strike_rate >> Bo[i].Batting_average >> Bo[i].Best_Batting_figure >> Bo[i].Fours >> Bo[i].Sixes;
    }
    for (int i = 53; i < 83; i++)
    {
        allrounder >> id[i] >> Ar[i - 53].First_name >> Ar[i - 53].Last_name >> Ar[i - 53].Age >> Ar[i - 53].Team >> Ar[i - 53].Country >> Ar[i - 53].No_of_matches >> Ar[i - 53].Innings >> Ar[i - 53].Runs >> Ar[i - 53].Batting_strike_rate >> Ar[i - 53].Batting_average >> Ar[i - 53].Fifties >> Ar[i - 53].Centuries >> Ar[i - 53].Best_Batting_figure >> Ar[i - 53].Fours >> Ar[i - 53].Sixes >> Ar[i - 53].Wickets >> Ar[i - 53].Economy >> Ar[i - 53].Bowling_average >> Ar[i - 53].Best_Bowling_figure >> Ar[i - 53].Four_wkt_hauls;
    }

    float eco[83];
    for (int i = 0; i < 53; i++)
        eco[i] = Bo[i].Economy;

    for (int i = 53; i < 83; i++)
        eco[i] = Ar[i - 53].Economy;

    int tot = 83;
    for (int i = 0; i < tot; i++)
    {
        if (eco[i] == 0)
        {
            for (int j = i; j < (tot - 1); j++)
                eco[j] = eco[j + 1];
            i--;
            tot--;
        }
    }

    int n = sizeof(eco) / sizeof(eco[0]);
    sort(eco, eco + n);

    int n1 = 83;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (eco[i] == eco[j]) //checks for multiple instances of same runs
            {
                for (int k = j; k < n1 - 1; ++k)
                    eco[k] = eco[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo  F.Name     L.Name       TEAM                        TM    Eco" << endl
         << endl
         << endl;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 53; j++)
        {
            if (eco[i] == Bo[j].Economy) // checks where the given (eco) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Bo[j].First_name << setw(14) << Bo[j].Last_name << setw(28) << Bo[j].Team << setw(5) << Bo[j].No_of_matches << setw(5) << Bo[j].Economy << endl;
                cout << "--------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 30; j++)
        {
            if (eco[i] == Ar[j].Economy) // checks where the given (eco) occurs in the stat file
            {
                cout << left << setw(5) << id[i] << setw(11) << Ar[j].First_name << setw(14) << Ar[j].Last_name << setw(28) << Ar[j].Team << setw(5) << Ar[j].No_of_matches << setw(5) << Ar[j].Economy << endl;
                cout << "--------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_goal( vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D)
{
    fstream forward("attack.txt");
    if (!forward)
        cout << "Error opening the file!!" << endl;
    fstream midf("midfield.txt");
    if (!midf)
        cout << "Error opening the file!!" << endl;
    fstream defence("DEFENDERS.txt");
    if (!defence)
        cout << "Error opening the file!!" << endl;

    forward.seekg(0);
    midf.seekg(0);
    defence.seekg(0);

    int id[276];
    int _id = 1;
    for (int i = 0; i < 276; i++)
    {
        id[i] = _id;
        _id++;
    }

    for (int i = 0; i < 58; i++)
    {
        forward >> A[i].First_name >> A[i].Last_name >> A[i].Position >> A[i].Age >> A[i].Team >> A[i].Country >> A[i].No_of_matches >> A[i].Goals >> A[i].Shot_accuracy >> A[i].Assist >> A[i].Pass_Accuracy >> A[i].Red_card;
    }
    for (int i = 58; i < 169; i++)
    {
        midf >> Mf[i - 58].First_name >> Mf[i - 58].Last_name >> Mf[i - 58].Position >> Mf[i - 58].Age >> Mf[i - 58].Team >> Mf[i - 58].Country >> Mf[i - 58].No_of_matches >> Mf[i - 58].Goals >> Mf[i - 58].Shot_accuracy >> Mf[i - 58].Assist >> Mf[i - 58].Pass_Accuracy >> Mf[i - 58].Red_card;
    }
    for (int i = 169; i < 276; i++)
    {
        defence >> D[i - 169].First_name >> D[i - 169].Last_name >> D[i - 169].Position >> D[i - 169].Age >> D[i - 169].Team >> D[i - 169].Country >> D[i - 169].No_of_matches >> D[i - 169].Tackles_won >> D[i - 169].Clearance >> D[i - 169].Blocked_shots >> D[i - 169].Red_card >> D[i - 169].Goals >> D[i - 169].Pass_Accuracy;
    }
    int goalrt[276];
    for (int i = 0; i < 58; i++)
        goalrt[i] = A[i].Goals;

    for (int i = 58; i < 169; i++)
        goalrt[i] = Mf[i - 58].Goals;

    for (int i = 169; i < 276; i++)
        goalrt[i] = D[i - 169].Goals;

    int n = sizeof(goalrt) / sizeof(goalrt[0]);
    sort(goalrt, goalrt + n, greater<int>());

    int n1 = 276;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (goalrt[i] == goalrt[j]) //checks for multiple instances of same goals
            {
                for (int k = j; k < n1 - 1; ++k)
                    goalrt[k] = goalrt[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo Name                    Pos  Age Club                  Country      GP   Goals" << endl
         << endl;
    int check = 1;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 58; j++)
        {
            if (goalrt[i] == A[j].Goals && check <= 10) // checks where the given (goals) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << A[j].First_name << setw(14) << A[j].Last_name << setw(5) << A[j].Position << setw(4) << A[j].Age << setw(22) << A[j].Team << setw(13) << A[j].Country << setw(5) << A[j].No_of_matches << setw(6) << A[j].Goals << endl;
                cout << "----------------------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 111; j++)
        {
            if (goalrt[i] == Mf[j].Goals && check <= 10) // checks where the given (goals) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << Mf[j].First_name << setw(14) << Mf[j].Last_name << setw(5) << Mf[j].Position << setw(4) << Mf[j].Age << setw(22) << Mf[j].Team << setw(13) << Mf[j].Country << setw(5) << Mf[j].No_of_matches << setw(6) << Mf[j].Goals << endl;
                cout << "----------------------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 107; j++)
        {
            if (goalrt[i] == D[j].Goals && check <= 10) // checks where the given (goals) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << D[j].First_name << setw(14) << D[j].Last_name << setw(5) << D[j].Position << setw(4) << D[j].Age << setw(22) << D[j].Team << setw(13) << D[j].Country << setw(5) << D[j].No_of_matches << setw(7) << D[j].Goals << endl;
                cout << "-----------------------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_cleansheet(vector<GoalKeeper>& Gk)
{
    fstream gk("gk.txt");
    if (!gk)
        cout << "Error opening the file!!" << endl;

    gk.seekg(0);

    int id[27];
    int _id = 1;
    for (int i = 0; i < 27; i++)
    {
        id[i] = _id;
        _id++;
    }

    for (int i = 0; i < 27; i++)
    {
        gk >> Gk[i].First_name >> Gk[i].Last_name >> Gk[i].Position >> Gk[i].Age >> Gk[i].Team >> Gk[i].Country >> Gk[i].No_of_matches >> Gk[i].Clean_sheets >> Gk[i].Saves_made >> Gk[i].Goals_conceeded >> Gk[i].Red_card;
    }

    int cs[27];
    for (int i = 0; i < 27; i++)
        cs[i] = Gk[i].Clean_sheets;

    int n = sizeof(cs) / sizeof(cs[0]);
    sort(cs, cs + n, greater<int>());

    int n1 = 27;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (cs[i] == cs[j]) //checks for multiple instances of same goals
            {
                for (int k = j; k < n1 - 1; ++k)
                    cs[k] = cs[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo Name                    Pos  Age Club                  Country      GP   C.Sheet" << endl
         << endl;

    int check = 1;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 58; j++)
        {
            if (cs[i] == Gk[j].Clean_sheets && check <= 10) // checks where the given (cleansheet) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << Gk[j].First_name << setw(14) << Gk[j].Last_name << setw(5) << Gk[j].Position << setw(4) << Gk[j].Age << setw(22) << Gk[j].Team << setw(13) << Gk[j].Country << setw(5) << Gk[j].No_of_matches << setw(6) << Gk[j].Clean_sheets << endl;
                cout << "------------------------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_assist( vector<Attack>& A, vector<MidField>& Mf)
{
    fstream forward("attack.txt");
    if (!forward)
        cout << "Error opening the file!!" << endl;
    fstream midf("midfield.txt");
    if (!midf)
        cout << "Error opening the file!!" << endl;

    forward.seekg(0);
    midf.seekg(0);

    int id[169];
    int _id = 1;
    for (int i = 0; i < 169; i++)
    {
        id[i] = _id;
        _id++;
    }

    for (int i = 0; i < 58; i++)
    {
        forward >> A[i].First_name >> A[i].Last_name >> A[i].Position >> A[i].Age >> A[i].Team >> A[i].Country >> A[i].No_of_matches >> A[i].Goals >> A[i].Shot_accuracy >> A[i].Assist >> A[i].Pass_Accuracy >> A[i].Red_card;
    }
    for (int i = 58; i < 169; i++)
    {
        midf >> Mf[i - 58].First_name >> Mf[i - 58].Last_name >> Mf[i - 58].Position >> Mf[i - 58].Age >> Mf[i - 58].Team >> Mf[i - 58].Country >> Mf[i - 58].No_of_matches >> Mf[i - 58].Goals >> Mf[i - 58].Shot_accuracy >> Mf[i - 58].Assist >> Mf[i - 58].Pass_Accuracy >> Mf[i - 58].Red_card;
    }

    int assrt[169];
    for (int i = 0; i < 58; i++)
        assrt[i] = A[i].Assist;

    for (int i = 58; i < 169; i++)
        assrt[i] = Mf[i - 58].Assist;

    int n = sizeof(assrt) / sizeof(assrt[0]);
    sort(assrt, assrt + n, greater<int>());

    int n1 = 169;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (assrt[i] == assrt[j]) //checks for multiple instances of same goals
            {
                for (int k = j; k < n1 - 1; ++k)
                    assrt[k] = assrt[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo Name                    Pos  Age Club                  Country      GP   Assist" << endl
         << endl;

    int check = 1;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 58; j++)
        {
            if (assrt[i] == A[j].Assist && check <= 10) // checks where the given (assist) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << A[j].First_name << setw(14) << A[j].Last_name << setw(5) << A[j].Position << setw(4) << A[j].Age << setw(22) << A[j].Team << setw(13) << A[j].Country << setw(5) << A[j].No_of_matches << setw(6) << A[j].Assist << endl;
                cout << "-----------------------------------------------------------------------------------" << endl;
            }
        }
        for (int j = 0; j < 111; j++)
        {
            if (assrt[i] == Mf[j].Assist && check <= 10) // checks where the given (assist) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << Mf[j].First_name << setw(14) << Mf[j].Last_name << setw(5) << Mf[j].Position << setw(4) << Mf[j].Age << setw(22) << Mf[j].Team << setw(13) << Mf[j].Country << setw(5) << Mf[j].No_of_matches << setw(6) << Mf[j].Assist << endl;
                cout << "-----------------------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_defenders(vector<Defence>& D)
{

    fstream defence("DEFENDERS.txt");
    if (!defence)
        cout << "Error opening the file!!" << endl;

    defence.seekg(0);

    int id[107];
    int _id = 1;
    for (int i = 0; i < 107; i++)
    {
        id[i] = _id;
        _id++;
    }

    for (int i = 0; i < 107; i++)
    {
        defence >> D[i].First_name >> D[i].Last_name >> D[i].Position >> D[i].Age >> D[i].Team >> D[i].Country >> D[i].No_of_matches >> D[i].Tackles_won >> D[i].Clearance >> D[i].Blocked_shots >> D[i].Red_card >> D[i].Goals >> D[i].Pass_Accuracy;
    }
    int clrt[107];
    for (int i = 0; i < 107; i++)
        clrt[i] = D[i].Clearance;

    int n = sizeof(clrt) / sizeof(clrt[0]);
    sort(clrt, clrt + n, greater<int>());

    int n1 = 107;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (clrt[i] == clrt[j]) //checks for multiple instances of same goals
            {
                for (int k = j; k < n1 - 1; ++k)
                    clrt[k] = clrt[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo Name                    Pos  Age Club                  Country      GP   Clearance" << endl
         << endl;

    int check = 1;
    for (int i = 0; i < 10; i++)
    {

        for (int j = 0; j < 107; j++)
        {
            if (clrt[i] == D[j].Clearance && check <= 10) // checks where the given (clearance) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << id[i] << setw(10) << D[j].First_name << setw(14) << D[j].Last_name << setw(5) << D[j].Position << setw(4) << D[j].Age << setw(22) << D[j].Team << setw(13) << D[j].Country << setw(5) << D[j].No_of_matches << setw(7) << D[j].Clearance << endl;
                cout << "--------------------------------------------------------------------------------------" << endl;
            }
        }
    }
}
void Display_top10_leastgoal(vector<GoalKeeper>& Gk)
{
    fstream gk("gk.txt");
    if (!gk)
        cout << "Error opening the file!!" << endl;

    gk.seekg(0);

    int id[27];
    int _id = 1;
    for (int i = 0; i < 27; i++)
    {
        id[i] = _id;
        _id++;
    }

    for (int i = 0; i < 27; i++)
    {
        gk >> Gk[i].First_name >> Gk[i].Last_name >> Gk[i].Position >> Gk[i].Age >> Gk[i].Team >> Gk[i].Country >> Gk[i].No_of_matches >> Gk[i].Clean_sheets >> Gk[i].Saves_made >> Gk[i].Goals_conceeded >> Gk[i].Red_card;
    }

    int gc[27];
    for (int i = 0; i < 27; i++)
        gc[i] = Gk[i].Goals_conceeded;

    int tot = 83;
    for (int i = 0; i < tot; i++)
    {
        if (gc[i] == 0)
        {
            for (int j = i; j < (tot - 1); j++)
                gc[j] = gc[j + 1];
            i--;
            tot--;
        }
    }

    int n = sizeof(gc) / sizeof(gc[0]);
    sort(gc, gc + n);

    int n1 = 27;
    for (int i = 0; i < n1; ++i)
    {
        for (int j = i + 1; j < n1;)
        {
            if (gc[i] == gc[j]) //checks for multiple instances of same goals
            {
                for (int k = j; k < n1 - 1; ++k)
                    gc[k] = gc[k + 1];
                --n1;
            }
            else
                ++j;
        }
    }

    cout << "SNo Name                    Pos  Age Club                  Country      GP   Goal Conceeded" << endl
         << endl;

    int check = 1;
    int s_no = 1;
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 58; j++)
        {
            if (gc[i] == Gk[j].Goals_conceeded && check <= 10) // checks where the given (gc) occurs in the stat file
            {
                check++;
                cout << left << setw(4) << s_no << setw(10) << Gk[j].First_name << setw(14) << Gk[j].Last_name << setw(5) << Gk[j].Position << setw(4) << Gk[j].Age << setw(22) << Gk[j].Team << setw(13) << Gk[j].Country << setw(5) << Gk[j].No_of_matches << setw(5) << Gk[j].Goals_conceeded << endl;
                cout << "-------------------------------------------------------------------------------------------" << endl;
                s_no++;
            }
        }
    }
}
// ---------- FOOTBALL MENUS ----------

void footballStatsTopMenu(vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D, vector<GoalKeeper>& Gk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Football <<<<<<" << endl << endl;
        cout << "\t\t\t\tX----- View League Leaders -----X" << endl << endl;
        cout << "\t\t\t\t1. Top Goal Scorers" << endl
             << "\t\t\t\t2. Top Assists" << endl
             << "\t\t\t\t3. Cleansheets" << endl
             << "\t\t\t\t4. Top Defenders " << endl
             << "\t\t\t\t5. Least Goals Conceeded" << endl
             << "\t\t\t\t6. Return to Main Menu" << endl
             << "\t\t\t\t0. Exit the program" << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int top;
        cin >> top;
        switch (top) {
            case 1:
                Display_top10_goal(A, Mf, D);
                break;
            case 2:
                Display_top10_assist(A, Mf);
                break;
            case 3:
                Display_top10_cleansheet(Gk);
                break;
            case 4:
                Display_top10_defenders(D);
                break;
            case 5:
                Display_top10_leastgoal(Gk);
                break;
            case 6:
                return;
          
            default:
                cout << "No such option available! Please try again!" << endl;
        }
    }
}
void footballStatsByPositionMenu(vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D, vector<GoalKeeper>& Gk) {
    while (true) {
        cout << "\t\t\t\t1. Forward" << endl
             << "\t\t\t\t2. Mid-Field" << endl
             << "\t\t\t\t3. Defence " << endl
             << "\t\t\t\t4. Goal-keeper" << endl
             << "\t\t\t\t5. Return to Main Menu" << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int position;
        cin >> position;
        switch (position) {
            case 1:
                for (auto& h : A) {
                    h.Display_stats_f_a(A);
                }
                break;
            case 2:
                for (auto& h : Mf) {
                    h.Display_stats_f_m(Mf);
                }
                break;
            case 3:
                for (auto& h : D) {
                    h.Display_stats_f_d(D);
                }
                break;
            case 4:
                for (auto& h : Gk) {
                    h.Display_stats_f_gk(Gk);
                }
                break;
            case 5:
                return;
            default:
                cout << "No such option available! Please try again!" << endl;
        }
    }
}

void footballPlayerMenu(vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D, vector<GoalKeeper>& Gk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Football <<<<<<" << endl << endl;
        cout << "\t\t\t\tX--------- View Players --------X" << endl << endl;
        cout << "\t\t\t\t1. Search Player " << endl
             << "\t\t\t\t2. View All Players " << endl
             << "\t\t\t\t3. Return to Main Menu" << endl
             << "\t\t\t\t0. Exit the program " << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int player;
        cin >> player;
        if (player == 1) {
            while (true) {
                cout << "\t\t\t\t1. Forward" << endl
                     << "\t\t\t\t2. Mid-Fielder" << endl
                     << "\t\t\t\t3. Defender " << endl
                     << "\t\t\t\t4. Goal-Keeper" << endl
                     << "\t\t\t\t5. Return to Main Menu" << endl << endl;
                cout << "\t\t\t\tEnter your choice: ";
                int category;
                cin >> category;
                string name;
                switch (category) {
                    case 1:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : A){ 
                       h.Search_player_f_a(A, name);}
                        break;
                  case 2:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : Mf) {
                            h.Search_player_f_m(Mf, name);
                        }
                        break;
                  case 3:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : D) {
                         h.Search_player_f_d(D, name);
                    }
                    break;
                  case 4:
                 cout << "Enter name of the player to search : ";
                  cin >> name;
                  for (auto& h : Gk) {
                     h.Search_player_f_gk(Gk, name);
                 }
                 break;
                    case 5:
                    return ;
                    default:
                        cout << "No such option available! Please try again!" << endl;
                }
            }
        }
     else if (player == 2)
         {      
        for (auto& h : A) {
            h.Player_display_f_a(A);
        }
        for (auto& h : Mf) {
            h.Player_display_f_m(Mf);
        }
        for (auto& h : D) {
            h.Player_display_f_d(D);
        }
        for (auto& h : Gk) {
            h.Player_display_f_gk(Gk);
        }

        } else if (player == 3) {
            return;
        } else if (player == 0) {
            exit(0);
        } else {
            cout << "No such option available! Please try again!" << endl;
        }
    }
}
void footballStatsMenu(vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D, vector<GoalKeeper>& Gk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Football <<<<<<" << endl << endl;
        cout << "\t\t\t\tX---------- View Stats ---------X" << endl << endl;
        cout << "\t\t\t\t1. View Top Players" << endl
             << "\t\t\t\t2. View Stats by Positions " << endl
             << "\t\t\t\t3. Return to Main Menu" << endl
             << "\t\t\t\t0. Exit the program" << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int stat;
        cin >> stat;
        if (stat == 1) {
            footballStatsTopMenu(A, Mf, D, Gk);
        } else if (stat == 2) {
            footballStatsByPositionMenu(A, Mf, D, Gk);
        } else if (stat == 3) {
            return;
        } else if (stat == 0) {
            exit(0);
        } else {
            cout << "No such option available! Please try again!" << endl;
        }
    }
}
void footballMenu(vector<Football>& F, vector<Attack>& A, vector<MidField>& Mf, vector<Defence>& D, vector<GoalKeeper>& Gk) {
    while (true) {
        if (!F.empty()) {
            F[0].displaymain(); 
        } 
        else {
            cout << "No football data available!" << endl;
            return;
        }

        int switch_f;
        cin >> switch_f;
        switch (switch_f) {
            case 1:
                if (!F.empty()) {
                    F[0].Team_display_f(); // Display teams using the first Football object
                }

                break;
            case 2:
                footballPlayerMenu(A, Mf, D, Gk);
                break;
            case 3:
                footballStatsMenu(A, Mf, D, Gk);
                break;
            case 4:
                if (!F.empty()) {
                    F[0].Standings_display_f(); // Display standings using the first Football object
                }
                break;
            case 5:
                return; // Back to main menu
            case 0:
                exit(0);
            default:
                cout << "No such option available! Please Try Again" << endl;
        }
    }
}

// ---------- CRICKET MENUS ----------
void cricketStatsTopMenu(vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Cricket <<<<<<" << endl << endl;
        cout << "\t\t\t\tX----- View League Leaders -----X" << endl << endl;
        cout << "\t\t\t\t1. Top Run Scorers" << endl
             << "\t\t\t\t2. Highest Batting Strike Rates" << endl
             << "\t\t\t\t3. Highest Batting Average" << endl
             << "\t\t\t\t4. Top Wicket Takers" << endl
             << "\t\t\t\t5. Best Bowling Average" << endl
             << "\t\t\t\t6. Best Economy Rate" << endl
             << "\t\t\t\t7. Return to Previous Menu " << endl
             << "\t\t\t\t0. Exit" << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int field;
        cin >> field;
        switch (field) {
            case 1:
                Display_top10_run(Bt, Bo, Ar, Wk);
                break;
            case 2:
                Display_top10_strikerate(Bt, Ar, Wk);
                break;
            case 3:
                Display_top10_batavg(Bt, Ar, Wk);
                break;
            case 4:
                Display_top10_wkt(Bo, Ar);
                break;
            case 5:
                Display_top10_bowlavg(Bo, Ar);
                break;
            case 6:
                Display_top10_eco(Bo, Ar);
                break;
            case 7:
                return;
           case 0:
                false;
                 break;
            default:
                cout << "No such option available! Please try again!" << endl;
        }
    }
}
void cricketStatsByCategoryMenu(vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    while (true) {
        cout << "1. Batsman" << endl
             << "2. Bowler" << endl
             << "3. All-Rounder " << endl
             << "4. Wicket-Keeper" << endl
             << "5. Return to Main Menu" << endl;
        cout << "Enter your choice: ";
        int category;
        cin >> category;
        switch (category) {
            case 1:
             for( auto h: Bt)
                h.Display_stats_c_bt(Bt);
                break;
            case 2:
             for( auto h: Bo)
                h.Display_stats_c_bo(Bo);
                break;
            case 3:
                for(auto h: Ar)
                h.Display_stats_c_ar(Ar);
                break;
            case 4:
                for(auto h: Wk)
                h.Display_stats_c_wk(Wk);
                break;
            case 5:
                return;
            default:
                cout << "No such option available! Please try again!" << endl;
        }
    }
}

void cricketPlayerMenu(vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Cricket <<<<<<" << endl << endl;
        cout << "\t\t\t\tX--------- View Players --------X" << endl << endl;
        cout << "\t\t\t\t1. Search Player " << endl
             << "\t\t\t\t2. View All Players " << endl
             << "\t\t\t\t3. Return to Main Menu" << endl
             << "\t\t\t\t0. Exit the program " << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int player;
        cin >> player;
        if (player == 1) {
            while (true) {
                cout << "                                  1. Batsman" << endl
                     << "                                  2. Bowler" << endl
                     << "                                  3. All-Rounder " << endl
                     << "                                  4. Wicket-Keeper" << endl
                     << "                                  5. Return to Main Menu" << endl << endl;
                cout << "                                  Enter your choice: ";
                int category;
                cin >> category;
                string name;
                if (category >= 1 && category <= 4) {
                    cout << "Enter name of the player to search : ";
                    cin >> name;
                }
                switch (category) {
                    case 1:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : Bt) {
                            h.Search_player_c_bt(Bt, name);
                        }
                        break;
                    case 2:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : Bo) {
                            h.Search_player_c_bo(Bo, name);
                        }
                        break;
                    case 3:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : Ar) {
                            h.Search_player_c_ar(Ar, name);
                        }
                        break;
                    case 4:
                        cout << "Enter name of the player to search : ";
                        cin >> name;
                        for (auto& h : Wk) {
                            h.Search_player_c_wk(Wk, name);
                        }
                        break;
                    case 5:
                        return;
                    case 0:
                       false;
                       break;
                    default:
                        cout << "No such option available! Please try again!" << endl;
                }
            }
            
        } else if (player == 2) {
            for (auto& h : Bt) {
                h.Player_display_c_bt(Bt);
            }
            
            for (auto& h : Bo) {
                h.Player_display_c_bo(Bo);
            }
            
            for (auto& h : Ar) {
                h.Player_display_c_ar(Ar);
            }
            
            for (auto& h : Wk) {
                h.Player_display_c_wk(Wk);
            }
        } else if (player == 3) {
            return;
        } else if (player == 0) {
            exit(0);
        } else {
            cout << "No such option available! Please try again!" << endl;
        }
    }
}
void cricketStatsMenu(vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    while (true) {
        cout << "\t\t\t\t>>>>>> Welcome to Cricket <<<<<<" << endl << endl;
        cout << "\t\t\t\tX---------- View Stats ---------X" << endl << endl;
        cout << "\t\t\t\t1. View League Leaders" << endl
             << "\t\t\t\t2. View Stats by Category " << endl
             << "\t\t\t\t3. Return to Main Menu" << endl
             << "\t\t\t\t0. Exit the program" << endl << endl;
        cout << "\t\t\t\tEnter your choice: ";
        int stat;
        cin >> stat;
        if (stat == 1) {
            cricketStatsTopMenu(Bt, Bo, Ar, Wk);
        } else if (stat == 2) {
            cricketStatsByCategoryMenu(Bt, Bo, Ar, Wk);
        } else if (stat == 3) {
            return;
        } else if (stat == 0) {
             
                       false;
                       break;
        } else {
            cout << "No such option available! Please try again!" << endl;
        }
    }
}

void cricketMenu(Cricket& C, vector<Batsman>& Bt, vector<Bowler>& Bo, vector<All_rounder>& Ar, vector<Wicket_keeper>& Wk) {
    while (true) {
        C.displaymain(); // Display the main cricket menu
        int switch_c;
        cin >> switch_c;

        switch (switch_c) {
            case 1:
                C.Team_display_c(); // Display cricket teams
                break;
            case 2:
                cricketPlayerMenu(Bt, Bo, Ar, Wk); // Navigate to player menu
                break;
            case 3:
                cricketStatsMenu(Bt, Bo, Ar, Wk); // Navigate to stats menu
                break;
            case 4:
                C.Standings_display_c(); // Display cricket standings
                break;
            case 5:
                return; // Return to the main menu
            case 0:
                       false;
                       break;
            default:
                cout << "No such option available! Please Try Again" << endl;
        }
    }
}

int main()
{   
    Player S;
    Cricket C;
vector<Football> F;
vector<Attack> A;
vector<MidField> Mf;
vector<Defence> D;
vector<GoalKeeper> Gk;
vector<Batsman> Bt;
vector<Bowler> Bo;
vector<All_rounder> Ar;
vector<Wicket_keeper> Wk;

    while (true) {
        S.displaymain();
        int num;
        cin >> num;

        switch (num) {
            case 1:
                footballMenu(F, A, Mf, D, Gk);
                break;
            case 2:
                cricketMenu(C, Bt, Bo, Ar, Wk);
                break;
          
            default:
                cout << "No such option available! Please Try Again" << endl;
        }
    }
    return 0;
}

